import { TechnologyListMockData } from "../../mock-data";

class TechnologyService {
  getAllTechnologies() {
    return TechnologyListMockData;
  }
  getTechnologyDetails(technologyId) {
    return TechnologyListMockData.find(
      (technology) => technology.technologyId === technologyId
    );
  }
}

export default new TechnologyService();
