import React, { useEffect, useState } from "react";

import technologyServiceObject from "../services/technology-service";

export const TechnologyDetails = ({ technologyId }) => {
  const [technology, setTechnology] = useState(null);
  useEffect(() => {
    setTechnology(technologyServiceObject.getTechnologyDetails(technologyId));
  }, [technologyId])
  if (technology) {
    return (
      <div>
        <h1>Details Of - {technology.technologyName}</h1>
        <table className="table table-hover table-striped">
          <tbody>
            <tr>
              <th>Technology Id</th>
              <td>{technology.technologyId}</td>
            </tr>
            <tr>
              <th>Technology Name</th>
              <td>{technology.technologyName}</td>
            </tr>
            <tr>
              <th>Category</th>
              <td>{technology.category}</td>
            </tr>
            <tr>
              <th>Features</th>
              <td>
                {technology.features.map((feature) => (
                  <p key={feature}>{feature}</p>
                ))}
              </td>
            </tr>
            <tr>
              <th>Current Version</th>
              <td>{technology.currentVersion}</td>
            </tr>
            <tr>
              <th>Most Appreciated Feature</th>
              <td>{technology.mostAppreciatedFeature}</td>
            </tr>
            <tr>
              <th>Release Year</th>
              <td>{technology.releaseYear}</td>
            </tr>
            <tr>
              <th>Current Ranking</th>
              <td>{technology.rank}</td>
            </tr>
            <tr>
              <th>Logo</th>
              <td>
                <img src={technology.logo} alt={technology.technologyName} />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );  
  }else{
    return <h1>Loading...</h1>
  }
  
};
