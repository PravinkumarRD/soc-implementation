import React, { useState, useEffect } from "react";
import { Modal, Button } from "react-bootstrap";

import technologyServiceObject from "../services/technology-service";

import { CardView } from "../../shared/components/CardView";
import { TechnologyDetails } from "./TechnologyDetails";

export const TechnologyList = () => {
  let title = "Welcome To Technology List!";
  let subTitle = "Choose the correct technology to give a feedback!";
  const [technologies, setTechnologies] = useState(null);
  const [selectedTechnologyId, setSelectedTechnologyId] = useState(0);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  useEffect(() => {
    (() => {
      setTechnologies(technologyServiceObject.getAllTechnologies());
    })();
  }, []);
  const onTechnologySelection = (technologyId) => {
    setSelectedTechnologyId(technologyId);
    handleShow();
  };
  if (technologies !== null) {
    return (
      <div>
        <h1>{title}</h1>
        <hr />
        <h6>{subTitle}</h6>
        <br />
        <div className="form-group">
          <label htmlFor="searchTechnologies" className="form-label mt-4">
            Search Your Technology
          </label>
          <input
            type="search"
            className="form-control"
            id="searchTechnologies"
            placeholder="Search your technologies"
            onChange={(e) => {
              if (e.target.value) {
                setTechnologies(
                  technologies.filter((tech) =>
                    tech.technologyName
                      .toLocaleLowerCase()
                      .includes(e.target.value.toLocaleLowerCase())
                  )
                );
              } else {
                setTechnologies(technologyServiceObject.getAllTechnologies());
              }
            }}
          />
        </div>
        <hr />
        <div className="container">
          <div className="row">
            {technologies.map((technology) => (
              <CardView
                key={technology.technologyId}
                id={technology.technologyId}
                header={technology.technologyName}
                image={technology.logo}
                alternateText={technology.technologyName}
                displayFooter={true}
                handleOnClick={() => { onTechnologySelection(technology.technologyId); }}
              />
            ))}
          </div>
        </div>
        <hr />
        {selectedTechnologyId>0 ? (
          <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
              <Modal.Title>Technology Details!</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <TechnologyDetails technologyId={selectedTechnologyId} />
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary" onClick={handleClose}>
                Close
              </Button>
            </Modal.Footer>
          </Modal>
        ) : (
          ""
        )}
      </div>
    );
  } else {
    return <h1>Loading...</h1>;
  }
};
