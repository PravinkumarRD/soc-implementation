import { TechnologyList } from "./technology/components/TechnologyList";

function App() {
  return (
    <div>
      <TechnologyList />
    </div>
  );
}

export default App;
